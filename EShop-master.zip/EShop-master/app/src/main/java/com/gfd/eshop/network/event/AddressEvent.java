package com.gfd.eshop.network.event;

public class AddressEvent {
}
